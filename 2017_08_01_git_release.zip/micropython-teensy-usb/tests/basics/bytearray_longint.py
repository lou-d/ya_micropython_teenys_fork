print(bytearray(2**65 - (2**65 - 1)))
