# test bignum power

i = 1 << 65

print(0 ** i)
print(i ** 0)
print(i ** 1)
print(i ** 2)
