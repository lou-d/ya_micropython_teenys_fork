s = {1, 2, 3, 4}
print(s.clear())
print(list(s))
