# tests list.clear
x = [1, 2, 3, 4]
x.clear()
print(x)
