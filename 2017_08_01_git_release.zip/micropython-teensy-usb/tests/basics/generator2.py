gen = (i for i in range(10))
for i in gen:
    print(i)
