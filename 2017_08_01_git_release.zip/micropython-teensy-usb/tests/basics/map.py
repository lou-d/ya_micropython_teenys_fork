print(list(map(lambda x: x & 1, range(-3, 4))))
print(list(map(abs, range(-3, 4))))
print(list(map(set, [[i] for i in range(-3, 4)])))
print(list(map(pow, range(4), range(4))))
