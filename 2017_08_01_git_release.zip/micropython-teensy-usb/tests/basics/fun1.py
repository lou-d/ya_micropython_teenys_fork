# calling a function

def f():
    print(1)
f()
