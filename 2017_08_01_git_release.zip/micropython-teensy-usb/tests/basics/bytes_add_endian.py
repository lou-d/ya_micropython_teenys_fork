# test bytes + other

import array

print(b"123" + array.array('i', [1]))
