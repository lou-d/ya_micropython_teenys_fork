# test builtin locals()

x = 123
print(locals()['x'])
