# test str of function

def f():
    pass
print(str(f)[:8])
