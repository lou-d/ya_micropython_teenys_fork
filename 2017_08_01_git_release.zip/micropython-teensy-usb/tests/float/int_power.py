# negative power should produce float

x = 2
print(x ** -2)

x = 3
x **= -2
print('%.5f' % x)
